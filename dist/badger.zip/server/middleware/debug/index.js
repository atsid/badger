module.exports = {
  send: require('./send'),
};
